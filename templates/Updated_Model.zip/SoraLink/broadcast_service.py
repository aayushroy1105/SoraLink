"""Persistent PA announcement lifecycle."""
