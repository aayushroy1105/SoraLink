"""SoraLink application configuration."""
